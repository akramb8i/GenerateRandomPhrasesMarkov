This program generate random English paragraphs using Markov chain algorithm. I knew about Markov chain from random process course but didn't know how to generate sentences using

that. I googled and found out that it's very easy using python random.choice library function.

The procedure is as follows:


1) first reading the input file form command line.

2) Ten storing the content of the file as words in a python dictionary.

3) Generate random phrases given P(prefix length) and N(output length)

